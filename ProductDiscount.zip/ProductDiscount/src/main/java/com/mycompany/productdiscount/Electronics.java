package com.mycompany.productdiscount;

public class Electronics extends Product {

    public Electronics(String name, double price) {
        super(name, price);
    }

    @Override
    public double getDiscountedPrice() {
        return getPrice() * 0.95;
    }
}
