package com.mycompany.productdiscount;

public class ProductDiscount {

    public static void main(String[] args) {

        Product[] products = {
            new Clothing("T-Shirt", 300),
            new Clothing("Jeans", 600),
            new Electronics("Laptop", 10000),
            new Electronics("Headphones", 1500)
        };

        for (Product product : products) {

            System.out.println("Product: " + product.getName());
            System.out.println("Original Price: R"
                    + product.getPrice());
            System.out.println("Discounted Price: R"
                    + product.getDiscountedPrice());

            System.out.println("----------------------");
        }
    }
}