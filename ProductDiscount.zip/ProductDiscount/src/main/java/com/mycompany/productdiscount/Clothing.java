package com.mycompany.productdiscount;

public class Clothing extends Product {

    public Clothing(String name, double price) {
        super(name, price);
    }

    @Override
    public double getDiscountedPrice() {
        return getPrice() * 0.90;
    }
}